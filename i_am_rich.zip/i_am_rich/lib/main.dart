import 'package:flutter/material.dart';

//The main function is the starting point for all the flutter apps
void main() {
  runApp(
    MaterialApp(
      home: Scaffold(
        backgroundColor: Colors.blueGrey,
        appBar: AppBar(
          title: Text('I am Rich'),
          backgroundColor: Colors.blueGrey[900],
        ),
        body: Center(
          child: Image(
            image: NetworkImage(
              'https://media.istockphoto.com/photos/large-group-of-baby-chicks-on-chicken-farm-picture-id157375734?k=6&m=157375734&s=612x612&w=0&h=jQeuEQuOCXJfIoevWDnJ26TB7gbAW2s3_3sM5qf8iIQ=',
            ),
          ),
        ),
      ),
    ),
  );
}
